package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val findMovieButton= findViewById<Button>(R.id.find_movie)
        findMovieButton.setOnClickListener{
            val genreChoice= findViewById<Spinner>(R.id.movie_choice)
            val genre = genreChoice.selectedItem
            val movieList= getmovie(genre.toString())
            val movies= movieList.reduce { str, item->str + '\n' + item}
            val movieTypes = findViewById<TextView>(R.id.movies)
            movieTypes.text = movies

        }
    }
    fun getmovie(genre: String) : List<String> {
        return when (genre) {
            "Action" -> listOf("Red Notice", "Jumanji")
            "Horror" -> listOf("Mirzapur", "House of Dragon")
            "Thrill" -> listOf("Charmsukh", "Andheri Raat")
            "Crime"  -> listOf("Ragni", "Apharan")
            "Drama" -> listOf("The Stand","Shark Tank")
            "Comedy" -> listOf("Abhay","Family")
            else -> listOf("Web Series", "TV Shows")

        }
    }
}